Overview:
VaultList is a simple tool that lists all of the files in the Vault. 
 
VaultList contains the following features/concepts:
	- Log in/security
	- Browsing folders and files


To Use:
Open VaultList.sln in Visual Studio.  The project should open with no errors.


Known issues:
- There is almost no error handling code.  
