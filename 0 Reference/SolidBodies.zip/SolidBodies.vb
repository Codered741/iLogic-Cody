﻿'Option Strict On

Imports System
Imports System.Collections.Generic
Imports Inventor

Public Class SolidBodies
	Public ReadOnly doc As Document
	Public SurfaceBodies As SurfaceBodies

	Public Sub New(ByVal doc_in As Document)
		doc = doc_in
		If (doc.DocumentType <> DocumentTypeEnum.kPartDocumentObject) Then
			Throw New ArgumentException("SolidBodies: this document is not a part: " & doc.DisplayName)
		End If
		ReloadBodies()
	End Sub


	Default Public ReadOnly Property Body(ByVal name As String) As SolidBody
		Get
			Dim sb As SurfaceBody = FindBody(name)
			If (sb IsNot Nothing) Then
				Return New SolidBody(sb, doc)
			End If
			Throw New ArgumentException("SolidBodies.Body: No solid body was found with the name: " & name)
		End Get
	End Property

	Public Function Extents() As Double()
		Dim extentsBox As Box = Nothing
		ReloadBodies()
		For Each body As SurfaceBody In SurfaceBodies
			If (extentsBox Is Nothing) Then
				extentsBox = body.RangeBox
			Else
				Dim thisBox As Box = body.RangeBox
				extentsBox.Extend(thisBox.MinPoint)
				extentsBox.Extend(thisBox.MaxPoint)
			End If
		Next
		If (extentsBox Is Nothing) Then
			Throw New ArgumentException("SolidBodies.SolidExtents: no solids found in the part: " & doc.DisplayName)
		End If
		Return BoxExtents(extentsBox, doc)
	End Function

	Public Property BodyIsActive(ByVal name As String) As Boolean
		Get
			Dim body As SurfaceBody = FindBody(name)
			Return (body IsNot Nothing)
		End Get

		Set(ByVal value As Boolean)
			If (value = False) Then
				Dim body As SurfaceBody = FindBody(name)
				If (body IsNot Nothing) Then
					For Each feature As PartFeature In body.AffectedByFeatures
						feature.Suppressed = True
					Next
				End If
			Else
				' The body can't be found in the SurfaceBodies list.
				' Find the body feature names in the model browser, then unsuppress the features.
				Dim featureNames As List(Of String) = FindBodyFeatureNames(name)
				Dim partDoc As PartDocument = doc
				Dim features As PartFeatures = partDoc.ComponentDefinition.Features
				For Each featureName As String In featureNames
					Dim feature As PartFeature = FindFeature(features, featureName)
					feature.Suppressed = False
				Next
			End If
		End Set
	End Property

	Public Function FindBody(ByVal name As String) As SurfaceBody
		ReloadBodies()
		For Each sb As SurfaceBody In SurfaceBodies
			If (Not sb.IsSolid) Then Continue For
			If (sb.Name = name) Then
				Return sb
			End If
		Next
		Return Nothing
	End Function

	Public Function FindBodyFeatureNames(ByVal bodyName As String) As List(Of String)
		Dim pane As BrowserPane = doc.BrowserPanes("PmDefault")
		Dim rootNode As BrowserNode = pane.TopNode
		Dim featureNames As New List(Of String)

		For Each node As BrowserNode In rootNode.BrowserNodes
			If (node.NativeObject Is Nothing AndAlso node.FullPath.EndsWith("Solid Bodies")) Then	' TODO: support non-English
				For Each subNode As BrowserNode In node.BrowserNodes
					If (subNode.BrowserNodeDefinition.Label = bodyName) Then
						For Each featureNode As BrowserNode In subNode.BrowserNodes
							featureNames.Add(FeatureNameFromBrowser(featureNode.BrowserNodeDefinition))
						Next
						Return featureNames
					End If
				Next
			End If
		Next
		Return featureNames
	End Function

	Public Function FeatureNameFromBrowser(ByVal nodeDef As BrowserNodeDefinition) As String
		Dim name As String = nodeDef.Label
		Dim suppressedSuffix As String = " (Suppressed)" ' TODO: support non-English
		If (name.EndsWith(suppressedSuffix)) Then
			Return name.Substring(0, name.Length - suppressedSuffix.Length)
		End If
		Return name
	End Function

	Public Function FindFeature(ByVal features As PartFeatures, ByVal featureName As String) As PartFeature
		Try
			Return features.Item(featureName)
		Catch ex As System.Runtime.InteropServices.COMException
			Throw New ArgumentException("No feature found with the name: " + featureName)
		Catch ex As System.ArgumentException
			Throw New ArgumentException("No feature found with the name: " + featureName)
		End Try
	End Function

	Private Sub ReloadBodies()
		Dim partDoc As PartDocument = doc
		SurfaceBodies = partDoc.ComponentDefinition.SurfaceBodies
	End Sub

End Class


Public Class SolidBody
	Public ReadOnly SurfaceBody As SurfaceBody
	Public ReadOnly Document As Document

	Public Sub New(ByVal body As SurfaceBody, ByVal doc As Document)
		SurfaceBody = body
		Document = doc
	End Sub

	Public ReadOnly Property Extents() As Double()
		Get
			Return BoxExtents(SurfaceBody.RangeBox, Document)
		End Get
	End Property

	Public Property Visible() As Boolean
		Get
			Return SurfaceBody.Visible
		End Get
		Set(ByVal value As Boolean)
			SurfaceBody.Visible = value
		End Set
	End Property

	Public Property Color() As String
		Get
			Dim styleSource As StyleSourceTypeEnum
			Dim style As RenderStyle = SurfaceBody.GetRenderStyle(styleSource)
			If (styleSource <> StyleSourceTypeEnum.kOverrideRenderStyle) Then
				Return "As Part"
			End If
			Return style.Name
		End Get

		Set(ByVal value As String)
			Try
				If (String.Equals(value, "As Part", StringComparison.OrdinalIgnoreCase) OrElse _
					String.Equals(value, "As Material", StringComparison.OrdinalIgnoreCase)) Then
					SurfaceBody.SetRenderStyle(Inventor.StyleSourceTypeEnum.kPartRenderStyle, Nothing)
				Else
					Dim renderStyle As Inventor.RenderStyle = Document.RenderStyles.Item(value)
					If (renderStyle IsNot Nothing) Then
						SurfaceBody.SetRenderStyle(Inventor.StyleSourceTypeEnum.kOverrideRenderStyle, renderStyle)
					End If
				End If
			Catch ex As System.Runtime.InteropServices.COMException
				Throw New System.ArgumentException("SolidBody.Color: Probably an unknown color name: " & value)
			Catch ex As ArgumentException
				Throw New System.ArgumentException("SolidBody.Color: Probably an unknown color name: " & value)
			End Try
		End Set
	End Property

	Public ReadOnly Property Volume(Optional ByVal PrecisionPercent As Double = 0.01) As Double
		Get
			Dim vol As Double = SurfaceBody.Volume(PrecisionPercent)
			Dim volLength As Double = Math.Pow(vol, 1.0 / 3.0)
			volLength = LengthToDocumentUnits(volLength, Document.UnitsOfMeasure)
			vol = Math.Pow(volLength, 3.0)
			Return vol
		End Get
	End Property

End Class


Public Module SolidUtilities

	Public Function BoxExtents(ByVal box As Box, ByVal doc As Document) As Double()
		Dim extents(2) As Double
		Dim ptMin As Point = box.MinPoint
		Dim ptMax As Point = box.MaxPoint
		extents(0) = LengthToDocumentUnits(ptMax.X - ptMin.X, doc.UnitsOfMeasure)
		extents(1) = LengthToDocumentUnits(ptMax.Y - ptMin.Y, doc.UnitsOfMeasure)
		extents(2) = LengthToDocumentUnits(ptMax.Z - ptMin.Z, doc.UnitsOfMeasure)
		Return extents
	End Function

	Public Function LengthToDocumentUnits(ByVal length As Double, ByVal uom As UnitsOfMeasure) As Double
		Return uom.ConvertUnits(length, Inventor.UnitsTypeEnum.kDatabaseLengthUnits, uom.LengthUnits)
	End Function

End Module